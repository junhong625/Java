package chap04;

public class ArrayEx5 {

	public static void main(String[] args) {
		int[][]score = {
				{100,100,100},
				{20,20,20},
				{30,30,30},
				{40,40,40},
				{50,50,50}
		};
		System.out.println("--��ȣ-- | --����-- --����-- --����-- ");
		for (int i =0;i<score.length;i++) {
			System.out.print("   "+(i+1)+"��    |  ");
			for (int j=0;j<score[i].length;j++) {
				if(score[i][j]<100)
					System.out.print(score[i][j]+ "��   |");
				else
					System.out.print(score[i][j]+ "�� |");
				
			}System.out.println();
		}
		int[][] eng = {{95,100},{92,96,80}};//new int[2][];
		//eng[0] = new int[2];
		//eng[1] = new int[3];
		for(int i=0; i< eng.length;i++) {
			for(int j=0; j< eng[i].length;j++) {
				System.out.println("eng["+i+"]["+j+"]="+eng[i][j]);
			}
		}
	}
}
