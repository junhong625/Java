package chap04;

public class SwitchStatement_ {
	public static void main(String[] args) {
		//TODO Auto-generated method stub
	int score = 84;
	switch(score/10) {
		case 10 :
		case 9 :
			System.out.print("A");
			if(score >= 98) {
				System.out.println("+");
			}else if(score < 94) {
				System.out.println("-");
			}else {
				System.out.println("");
			}
			break;
		case 8 :
			System.out.print("B");
			if(score >= 88) {
				System.out.println("+");
			}else if(score < 84) {
				System.out.println("-");
			}else {
				System.out.println("");
			}
			break;
		case 7 :
			System.out.print("C");
			if(score >= 78) {
				System.out.println("+");
			}else if(score < 74) {
				System.out.println("-");
			}else {
				System.out.println("");
			}
			break;
		case 6 :
			System.out.print("D");
			if(score >= 68) {
				System.out.println("+");
			}else if(score < 64) {
				System.out.println("-");
			}else {
				System.out.println("");
			}
			break;
		default :
			System.out.println("F");
		}

	}
}
