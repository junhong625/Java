package chap04;

public class List {

	public static void main(String[] args) {
		int score[] = new int[5];
		System.out.println(score[2]);
		int score2[] = new int[] {100, 90, 80, 70, 60};
		System.out.println(score2[3]);
		int [] score3 = {100,90,80,70,60,50};
		for(int i=0; i<6; i++) {
			System.out.println(score3[i]);		}
		System.out.println(score3.length);
	}
}
