package chap04;

public class ArrayEx {

	public static void main(String[] args) {
		int score[] = {100, 90, 80};
		System.out.println("score [0]: " +score[0]);
		System.out.println("score [0]: " +score[1]);
		System.out.println("score [0]: " +score[2]);
		
		int sum = 0;
		for(int i=0; i < score.length; i++) {
			sum+=score[i];}
		System.out.println("�հ�: "+sum);
		
		double average = sum /score.length;
		System.out.println("���: "+ average);
	}
}
