package chap04;

//import java.util.Scanner;

public class DoWhileEx {

	public static void main(String[] args) {
		/*System.out.println("�޽����� �Է��Ͻÿ�.");
		System.out.println("���α׷��� �����Ϸ��� q�� �Է��Ͻÿ�.");
		
		Scanner s = new Scanner(System.in);
		String inputString;
		
		do {
				System.out.println(">");
				inputString = s.nextLine();
				System.out.println(inputString);
			}
		while(!inputString.equals("q")); {
			System.out.println("���α׷� ����");
		}
		int sum = 0;
		int i = 0;
		
		while(true) {
			if(sum>100)
				break;
			i++;
			sum+=i;
		}
		
		System.out.println("i=" + i);
		System.out.println("sum=" + sum);
		*/
		while(true) {
			int dice_num = (int) (Math.random()*6)+1;
			System.out.println(dice_num);
			if(dice_num == 6)
				break;}
		/*int dice_num=0;
		while(dice_num!=6) {
			dice_num = (int) (Math.random()*6)+1;
				System.out.println(dice_num);
		}*/
	}
}
