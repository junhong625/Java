package chap04;

public class IfStatement_ {

	public static void main(String[] args) {
		//TODO Auto-generated method stub
		int score = 98;
		if(score > 60) {
			System.out.println("�հ��Դϴ�.");
		}
		if(score > 60) {
			System.out.println("�հ��Դϴ�.");
		} else {
			System.out.println("���հ��Դϴ�.");
		}
		int num = 3;
		if(num > 0) {
			System.out.println("����Դϴ�.");
		} else if(num <0) {
			System.out.println("�����Դϴ�.");
		} else {
			System.out.println("0�Դϴ�.");
		}
		if(score >= 90) {
			String grade = ("A");
			if(score >= 98) {
				grade += "+";
			} else if (score < 94)  {
				grade += "-";
			}
		System.out.println(grade);
		} else if(score >= 80 && score < 90) {
			System.out.println("B���");
		} else if(score >= 70 && score < 80) {
			System.out.println("C���");
		} else if(score >= 60 && score < 70) {
			System.out.println("D���");
		} else {
			System.out.println("F���");
		}
		//String str = "";
		//char ch = ' ';
		//if(ch==' ' || ch =='\t')
	}
}

