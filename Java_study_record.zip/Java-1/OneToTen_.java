package chap04;

public class OneToTen_ {
	public static void main(String[] args) {
		int sum = 0;
		int i = 1;
		for(i=1; i <= 100; i++) {
			sum += i;
		}
		System.out.println(i -1 + "������ ��:" + sum);
		for(float x = 0.1f; x<= 1.0f; x += 0.1f) {
			System.out.println(x);
		}
	}
}
