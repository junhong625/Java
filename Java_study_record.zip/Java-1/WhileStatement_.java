package chap04;

public class WhileStatement_ {


	public static void main(String[] args) {
		/*int i =1;
		
		while (i <= 10) {
			System.out.println(i);
			i++;
		}
		*/
		int i = 1;
		
		int sum = 0;
		
		while(i<=100) {
			sum+=i;
			i++;
		}System.out.println(sum);
	}
}
		/*int j =1;
		while(j <= 9) {
			int k = 1;
			while(k <= 9) {
				System.out.println(j + " X " + k + "=" + (j*k));
				k++;
			}
			j++;
		}
		}
	}*/
