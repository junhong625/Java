package chap04;

public class Forstatement_ {

	public static void main(String[] args) {
		for(int i=1; i<=9; i++) {
			System.out.println("*** " + i + "���� �����մϴ� ***");
			System.out.println();
			for(int j=1; j<=9; j++) {
				int result = i*j;
				System.out.println(i + " X " + j + " = " + result);
			}
			System.out.println();
		}
		for(int i=1; i<=3; i++) {
			for(int j=1; j<=3; j++) {
				for(int k=1; k<=3; k++) {
					System.out.println(""+i+j+k);
				}
			}
		}
	}
}

