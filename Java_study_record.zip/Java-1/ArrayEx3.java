package chap04;

public class ArrayEx3 {

	public static void main(String[] args) {
		int[] ball = new int[45];
		for(int i=0; i<ball.length; i++)
			ball[i] = i+1;
		
		int temp=0;
		int j = 0;
		
		for(int i=0; i <100;i++) {
			j=(int) (Math.random()*45);
			temp = ball[0];
			ball[0] = ball[j];
			ball[j]=temp;
		}
		for(int i =0; i<6;i++)
			System.out.println(ball[i]+" ");
		
		int[] array1 = new int[3];
		for(int i = 0;i<array1.length;i++) {
			System.out.println("array1 ["+i+"] : "+array1[i]);
		}
		double[]array2 = new double[3];
		for (int i =0; i<array2.length;i++) {
			System.out.println("array2["+i+"] : "+ array2[i]);
		}
		String[]array3 = new String[3];
		for (int i =0; i<array3.length;i++) {
			System.out.println("array3["+i+"] : "+ array3[i]);
		}
		array3[0] = "1��";
		array3[1] = "2��";
		array3[2] = "3��";
		for (int i =0; i<array3.length;i++) {
			System.out.println("array3["+i+"] : "+ array3[i]);
		}
	}
}