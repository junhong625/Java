package chap04;

public class ArrayEx2 {

	public static void main(String[] args) {
		int scores[];
		scores = new int[] {100,90,70};
		
		int sum = 0;
		for(int i=0; i<scores.length; i++) {
			sum += scores[i];
		}
		System.out.println("�հ� : "+sum);
		
		
		/*public static int add() (int[] scores) {
			int sum2 = add(new int[] {100,90,80});
			System.out.println(sum2);
			int sum = 0;
			for(int i = 0; i <scores.length; i++) {
				sum+=score[i];
		}
			return sum;
		}*/
	}
}