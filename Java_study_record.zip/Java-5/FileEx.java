package chap11;

import java.io.File;

public class FileEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length != 1) {
			System.out.println("USAGE : java FileEx DIRECTORY");
			System.exit(0);
		}
	
		File f = new File(args[0]);
		
		if(!f.exists() || !f.isDirectory()) {
			System.out.println("��ȿ���� ���� ���丮�Դϴ�.");
			System.exit(0);
		}
		File[] file = f.listFiles();
		
		for(int i=0; i<file.length; i++) {
			String fileName = file[i].getName();
			System.out.println(file[i].isDirectory() ? "["+fileName+"]" : fileName);
		}
	}

}
