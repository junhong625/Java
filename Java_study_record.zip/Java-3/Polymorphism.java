package chap07;

class Tv2 {
	boolean power;
	int channel;
	
	void power () { power = !power;}
	void channelUp() { ++channel;}
	void channelDown() { --channel;}
}
class CaptionTv extends Tv2 {
	boolean caption;
	void displayCaption(String text) {
		if (caption) {
			System.out.println(text);
		}
	}
}


public class Polymorphism {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CaptionTv ctv = new CaptionTv();
		
		//Tv t = new CaptionTv();
		// t.caption = true; //�ڼ�Ÿ���� ���������� ����Ÿ���� �ν��Ͻ�(��ü) ���� �Ұ�
		
		ctv.channel = 10;
		ctv.channelUp();
		System.out.println(ctv.channel);
		
		ctv.displayCaption("Hello Wrold");
		ctv.caption = true;
		
		
		
	}
}

	