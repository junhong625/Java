package chap07;

public interface Inter {

}
