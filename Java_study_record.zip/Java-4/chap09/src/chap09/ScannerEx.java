package chap09;

import java.io.File;
import java.util.Scanner;

public class ScannerEx {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		File file = new File("test.txt");
		Scanner sc = new Scanner(file);
		int count = 0;
		int totalSum = 0;
		
		while(sc.hasNextLine()) {
			String line = sc.nextLine();
			Scanner sc2 = new Scanner(line).useDelimiter(",");
			int sum = 0;
			
			while(sc2.hasNextInt()) {
				sum+=sc2.nextInt();
			}
			System.out.println(line +", sum = " + sum);
			totalSum += sum;
			count++;
		}
		System.out.println("Line : "+count+ ", Total: "+totalSum);
	}

}
