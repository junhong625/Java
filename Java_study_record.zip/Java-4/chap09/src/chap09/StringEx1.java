package chap09;

import java.util.StringJoiner;

public class StringEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		char[] cArr = new char[] {'A', 'B','C'};
		String s = new String(cArr);
		
		System.out.println("cArr.length = " + cArr.length);
		System.out.println("***"+s+"***");
	}
		String animals = "dog, cat, bear";
		String[] arr = animals.split(",");
		
		System.out.println(String.join("-",  arr));
		StringJoiner sj = new StringJoiner("/","[","]");
		for(String s : arr)
			sj.add(s);
			
		System.out.println(sj.toString());
	}*/
//		int iVal = 100;
//		String strVal = String.valueOf(iVal);
//		
//		double dVal = 200.0;
//		String strVal2 = dVal + "";
//		
//		double sum = Integer.parseInt("+"+strVal) + Double.parseDouble(strVal2);
//		double sum2 = Integer.valueOf(strVal) + Double.valueOf(strVal2);
//		
//		System.out.println(String.join("", strVal, "+", strVal2,"=")+sum);
//		System.out.println(strVal + "+"+strVal2 + "=" + sum2);

		
		String fullName = "Hello.Java";
		int index = fullName.indexOf('.');
		String fileName = fullName.substring(0, index);
		String extension = fullName.substring(index+1);
		
		System.out.println(fullName + "�� ���� �̸��� " + fileName);
		System.out.println(fullName + "�� Ȯ���ڴ�" + extension);
	}
}