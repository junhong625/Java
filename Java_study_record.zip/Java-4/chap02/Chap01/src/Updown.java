
public class Updown {
	public static void main(String[] args) {
	char c1 = 'a';
	//char c2 = (char)(c1 + 1);
	char c2 = ++c1;
	System.out.println(c2);
	int i = 'b' + 'A';
	System.out.println(i);
	int i2 = '3' + '2';
	System.out.println(i2);
	System.out.println("----------");
	float pi = 3.141592f;
	float shortpi = (int)(pi * 1000) / 1000f;
	int intpi = (int)shortpi;
	System.out.println(intpi);
	
	}
}