
public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello, JAVA~!!");
		
		System.out.println("�ȴ�");;
		boolean a = false;
		System.out.println(a);
	}
}
	

