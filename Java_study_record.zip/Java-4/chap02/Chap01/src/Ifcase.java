
public class Ifcase {
	public static void main(String[] args) {
		//if��
		int num = 2;
		if(num==2) {
				System.out.println("SK");
		}	else if(num==4) { 
				System.out.println("KTF");
		}	else if(num==6) {
				System.out.println("LG");
		}	else {
				System.out.println("UNKNOWN");
		}
		//switch��
		switch(num) {
			case 6:
				System.out.println("SK");
				break;
			case 4:
				System.out.println("KTF");
				break;
			case 2:
				System.out.println("LG");
				break;
			default :
				System.out.println("UNKNOWN");
				break;
		}
	
	}
}
