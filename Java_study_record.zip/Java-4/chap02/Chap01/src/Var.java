
public class Var {
	
	
	public static void main(String[] args) {
		float pi = 3.14f;
		int score = 100;
		String str = "";
		System.out.println(str);
		System.out.println(str);
		System.out.println(score);
		System.out.println(pi);
		char c = 'a';
		System.out.println(c);
		byte b = 127;
		System.out.println(b);
		int pi2 = (int)pi;
		System.out.println(pi2);
		char score2 = (char)score;
		System.out.println(score2);
		float score3 = (float)score;
		System.out.println("���� ������ = ");
		System.out.println(score3);
		int i2 = 300;
		byte b2 = (byte)i2;
		System.out.println(b2);
		byte b3 =10;
		int i = b3;
		String j = 7 + 7 + "|" + 7 + 7;
		System.out.println(i);
		System.out.println("-------------------------------------------------");
		System.out.println(j);
		System.out.println(""+7+7);
		System.out.println(7+7+"");
		
	}
	
}
