
public class Bitcal {
	public static void main(String[] args) {
		int a = 0x185c;
		System.out.println(a);
		int b =0x000f;
		int c = 0x0005;
		System.out.println(b);
		System.out.println(a>>4);
		System.out.println(a >> 4 & b);
		System.out.println(c);
	}
}
