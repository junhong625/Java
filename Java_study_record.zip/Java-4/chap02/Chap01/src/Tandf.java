
public class Tandf {
	public static void main(String[] args) {
	int i = 7;
	boolean j = i>3 && i>5;
	boolean k = i>3 && i<0;
	System.out.println(j);
	System.out.println(k);
	
	}
}
