package chap05;

public class Student {
	int student_num ;
	String name;
	int age;
	int birthdate;
	String department;
	
	void study() {}
	void exam() {}
	void promote() {}
}

