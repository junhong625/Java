package chap05;

public class MymathTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mymath mm = new Mymath() ;
		long value = mm.add(1L,2L);
		System.out.println(value);
	}
}
