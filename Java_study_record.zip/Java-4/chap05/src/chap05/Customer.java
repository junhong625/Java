package chap05;

public class Customer {
	int customer_num;
	String name;
	int phone_num;
	String address;
	
	void order() {}
	void buy() {} 
	
}
