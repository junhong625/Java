package chap05;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Tv t;
		Tv t1=new Tv();
		Tv t2=new Tv();
		t2 = t1;
		
		t1.channel = 7;
		//t.channelDown ();
		System.out.println(t1.channel);
		System.out.println(t2.channel);
	}
}
