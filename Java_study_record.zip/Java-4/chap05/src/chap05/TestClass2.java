package chap05;

public class TestClass2 {
	int iv;
	static int cv;
	
	void instanceMethod() {
		System.out.println(iv);
		System.out.println(cv);
		
	}
	static void staticMethod () {
		//System.out.println(iv);
		System.out.println(cv);
	}
}

