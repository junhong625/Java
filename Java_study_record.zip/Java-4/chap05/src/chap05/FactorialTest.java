package chap05;

public class FactorialTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(factorial(3));
	}
	static long factorial(int n) {
		if (n==1)
			return 1;
		return n * factorial(n-1);
	}
}
