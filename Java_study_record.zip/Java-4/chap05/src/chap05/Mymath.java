package chap05;

public class Mymath {
	long add(long a, long b) {
		long result = a + b;
		return result; //return a + b;
	}
}
