package chap08;

public class ExceptionEx10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			method1(); 
		}
		catch (Exception e) {
			System.out.println("main �޼ҵ忡�� ���ܸ� ó���߽��ϴ�.");
			e.printStackTrace();
		}
	}
	static void method1() throws Exception{
		throw new Exception();
	}
}
